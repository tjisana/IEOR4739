#include <stdio.h>
#include <stdlib.h>
#include "bigbag.h"

int ALGcreatebigbag(bigbag **pbb, int n, int T, double *data)
{
  int retcode = 0;
  bigbag *pb;

  pb = (bigbag *)calloc(1, sizeof(bigbag));
  if(!pb){
    printf("no memory for bigbag\n"); retcode = NOMEM; goto BACK;
  }
  *pbb = pb;
  
  printf("created bigbag at %p\n", (void *) pb);

  pb->n = n; pb->T = T; pb->data = data;

 BACK:
  return retcode;
}
