#ifndef ALG

#define ALG

typedef struct bigbag{
  double *data;
  int n;
  int T;
}bigbag;

#define NOMEM 100
int ALGcreatebigbag(bigbag **pbb, int n, int T, double *data);




#endif
