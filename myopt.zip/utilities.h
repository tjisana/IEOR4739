#ifndef MYUTILS

#define MYUTILS

char *Ggettimestamp(void);


#endif
