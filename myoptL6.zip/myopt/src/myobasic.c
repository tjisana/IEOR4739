#include <stdio.h>
#include <stdlib.h>
#include "myopt.h"

int myoGetmyoFromFile(myo **ppmyo, char *filename)
{
  int retcode = 0;
  FILE *input = NULL;
  char buffer[100];
  int n, f, j, i;
  myo *pmyo = NULL;

  input = fopen(filename, "r");
  if(!input){
    printf("cannot open file %s\n", filename); retcode = 1; goto BACK;
  }
  printf("reading file %s\n", filename);

  fscanf(input,"%s",buffer);  fscanf(input,"%s",buffer);
  n = atoi(buffer);
  fscanf(input,"%s",buffer);  fscanf(input,"%s",buffer);
  f = atoi(buffer);
  printf("n = %d f = %d\n", n, f);

  if((retcode = myocreatemyo(&pmyo))) goto BACK;

  pmyo->n = n; pmyo->f = f;

  pmyo->mu = (double *)calloc(n, sizeof(double));
  pmyo->sigma = (double *)calloc(n, sizeof(double));
  pmyo->V = (double *)calloc(n*f, sizeof(double));
  pmyo->upper = (double *)calloc(n, sizeof(double));
  pmyo->lower = (double *)calloc(n, sizeof(double));
  pmyo->F = (double *)calloc(f*f, sizeof(double));

  if(!pmyo->mu || !pmyo->sigma || !pmyo->V || !pmyo->upper || !pmyo->lower 
     || !pmyo->F){
    printf("no memory for allocation\n"); retcode = NOMEM; goto BACK;
  }

  fscanf(input,"%s",buffer);  printf("%s\n", buffer);
  for(j = 0; j < n; j++){
    fscanf(input,"%s",buffer);
    pmyo->mu[j] = atof(buffer);
  }

  fscanf(input,"%s",buffer);  printf("%s\n", buffer);
  for(j = 0; j < n; j++){
    fscanf(input,"%s",buffer);
    pmyo->upper[j] = atof(buffer);
  }

  fscanf(input,"%s",buffer);  printf("%s\n", buffer);
  for(j = 0; j < n; j++){
    fscanf(input,"%s",buffer);
    pmyo->sigma[j] = atof(buffer);
  }


  fscanf(input,"%s",buffer);  printf("%s\n", buffer);
  for(j = 0; j < n; j++){
    for(i = 0; i < f; i++){
      fscanf(input,"%s",buffer);
      pmyo->V[i*n + j] = atof(buffer);
    }
  }

  fscanf(input,"%s",buffer);  printf("%s\n", buffer);
  for(j = 0; j < f; j++){
    for(i = 0; i < f; i++){
      fscanf(input,"%s",buffer);
      pmyo->F[i*f + j] = atof(buffer);
    }
  }


  fclose(input);

 BACK:
  printf("done reading with code %d\n", retcode);
  return retcode;
}

int myocreatemyo(myo **ppmyo)
{
  int retcode = 0;
  myo *pmyo;

  pmyo = (myo *)calloc(1, sizeof(myo));
  if(!pmyo){
    printf("no memory for myo\n"); retcode = NOMEM; goto BACK;
  }
  *ppmyo = pmyo;
  
  printf("created myo at %p\n", (void *) pmyo);

  printf(" Note: each myo takes %d bytes\n", (int) sizeof(myo));
  printf(" n is at %p\n", (void *)&(pmyo->n));
  printf(" f is at %p\n", (void *)&(pmyo->f));
  printf(" sigma is at %p\n", (void *)&(pmyo->sigma));
  printf(" V is at %p\n", (void *)&(pmyo->V));
  printf(" upper is at %p\n", (void *)&(pmyo->upper));

 BACK:
  return retcode;
}
