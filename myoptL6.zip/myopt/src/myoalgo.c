#include <stdio.h>
#include <stdlib.h>
#include "myopt.h"

int myofind_feasible(myo *pmyo);
int myo_iteration(myo *pmyo);

int myoalgo(myo *pmyo)
{
  int retcode = 0;
  int iteration, max_its = 2;

  if((retcode = myofind_feasible(pmyo))) goto BACK;

  for(iteration = 0; iteration < max_its; iteration++){
    if((retcode = myo_iteration(pmyo))) goto BACK;
  }

 BACK:
  printf("myoalgo returning with code %d\n", retcode);
  return retcode;
}

int myofind_feasible(myo *pmyo)
{
  int retcode = 0;

  return retcode;
}

int myo_iteration(myo *pmyo)
{
  int retcode = 0;

  return retcode;
}
