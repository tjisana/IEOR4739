#ifndef MYO

#define MYO

typedef struct myo{
  int n;
  int f;
  int iteration;
  double *mu;
  double *sigma;
  double *V;
  double *upper;
  double *lower;
  double *F;
}myo;

#define NOMEM 100
int myoGetmyoFromFile(myo **ppmyo, char *filename);
int myocreatemyo(myo **pmyo);
int myoalgo(myo *pmyo);

#include "utilities.h"

#endif
